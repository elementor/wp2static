<?php

namespace Github\Exception;

use Http\Client\Exception;

interface ExceptionInterface extends Exception
{
}
